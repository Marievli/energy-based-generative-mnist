from torchvision import datasets, transforms

def get_mnist_transforms():
    return transforms.Compose([
        transforms.ToTensor(),
    ])

def get_mnist_dataset(data_dir: str, train: bool):
    return datasets.MNIST(
        root=data_dir,
        train=train,
        transform=get_mnist_transforms(),
        download=True,
    )
