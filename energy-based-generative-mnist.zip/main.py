import yaml
import torch
import os

from src.utils.device import get_device
from src.utils.seed import seed_all
from src.data.loaders import build_mnist_loaders
from src.models import EBM
from src.sampling import ReplayBuffer, generate_samples
from src.training.trainer import Trainer



def load_config(path: str):
    with open(path, "r") as f:
        return yaml.safe_load(f)



def main(cfg):
    seed_all(cfg["seed"])
    device = get_device()
    print("Using device:", device)

    train_loader, test_loader = build_mnist_loaders(
        data_dir=cfg["data"]["data_dir"],
        batch_size=cfg["data"]["batch_size"],
        num_workers=cfg["data"]["num_workers"],
    )

    model = EBM(cfg).to(cfg["device"])


    optimizer = torch.optim.AdamW(
        model.parameters(), 
        lr=cfg["training"]["lr"], 
        betas=(0.0, 0.99), 
        weight_decay = 0.001  
    )

    scheduler = torch.optim.lr_scheduler.ReduceLROnPlateau(
        optimizer, 
        mode='min', 
        factor=0.5, 
        patience=5
    )
    
    output_dir = cfg["output"]["root"]
    checkpoint_dir = os.path.join(output_dir, cfg["output"]["checkpoints"])
    os.makedirs(checkpoint_dir, exist_ok=True)

    replay_buffer = ReplayBuffer(
        max_size=cfg["sampling"]["replay_buffer_size"]
    )

    trainer = Trainer(
        model=model,
        optimizer=optimizer,
        train_loader=train_loader,
        replay_buffer=replay_buffer,
        cfg=cfg,
        device=device,
    )

    trainer.train()

    samples = generate_samples(
        model=model,
        cfg=cfg,
        device=device,
    )

    print("Sampling finished. Generated samples shape:", samples.shape)



if __name__ == "__main__":
    cfg = load_config("configs/default.yaml")
    main(cfg)
