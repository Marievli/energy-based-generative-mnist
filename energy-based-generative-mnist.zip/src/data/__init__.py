import torch
from torch.utils.data import DataLoader
from torchvision import datasets, transforms
import matplotlib.pyplot as plt
import numpy as np


def get_transforms():
    return transforms.Compose([
        transforms.ToTensor()  
    ])


def load_mnist(data_dir: str, batch_size: int, num_workers: int = 2):
    transform = get_transforms()

    train_dataset = datasets.MNIST(
        root=data_dir,
        train=True,
        transform=transform,
        download=True
    )

    test_dataset = datasets.MNIST(
        root=data_dir,
        train=False,
        transform=transform,
        download=True
    )

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        drop_last=True
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        drop_last=False
    )

    return train_loader, test_loader


def show_batch(images, n_rows=2, n_cols=8, title=None):
    """
    images: Tensor of shape (B, 1, 28, 28)
    """
    images = images.detach().cpu()

    fig, axes = plt.subplots(n_rows, n_cols, figsize=(n_cols * 1.5, n_rows * 1.5))
    axes = axes.flatten()

    for i in range(n_rows * n_cols):
        img = images[i].squeeze(0)  # (28, 28)
        axes[i].imshow(img, cmap="gray")
        axes[i].axis("off")

    if title is not None:
        plt.suptitle(title)

    plt.tight_layout()
    plt.show()
