import torch
import torch.nn as nn
from torch.nn.utils import spectral_norm


class EBM(nn.Module):
    def __init__(self, in_channels=1, base_channels=32):
        super().__init__()

        def sn_conv(in_ch, out_ch, kernel, stride=1, padding=0):
            return spectral_norm(
                nn.Conv2d(in_ch, out_ch, kernel, stride, padding)
            )

        self.net = nn.Sequential(
            sn_conv(in_channels, base_channels, 3, 1, 1),
            nn.Mish(),

            sn_conv(base_channels, base_channels * 2, 4, 2, 1),
            nn.Mish(),

            sn_conv(base_channels * 2, base_channels * 2, 3, 1, 1),
            nn.Mish(),

            sn_conv(base_channels * 2, base_channels * 4, 4, 2, 1),
            nn.Mish(),

            sn_conv(base_channels * 4, base_channels * 8, 3, 1, 1),
            nn.Mish(),

            nn.AdaptiveAvgPool2d(1),
            nn.Flatten(),
            spectral_norm(nn.Linear(base_channels * 8, 64)),
            nn.Mish(),
            nn.Linear(64, 1),
        )

    def forward(self, x):
        energy = self.net(x).view(-1)
        return torch.tanh(energy / 10.0) * 10.0
