from torch.utils.data import DataLoader
from .mnist import get_mnist_dataset

def build_mnist_loaders(
    data_dir: str,
    batch_size: int,
    num_workers: int,
):
    train_dataset = get_mnist_dataset(data_dir, train=True)
    test_dataset = get_mnist_dataset(data_dir, train=False)

    train_loader = DataLoader(
        train_dataset,
        batch_size=batch_size,
        shuffle=True,
        num_workers=num_workers,
        drop_last=True,
    )

    test_loader = DataLoader(
        test_dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=num_workers,
        drop_last=False,
    )

    return train_loader, test_loader
