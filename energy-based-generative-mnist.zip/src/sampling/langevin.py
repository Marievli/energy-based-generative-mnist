import torch


def langevin_sampling(
    model,
    x_start,
    batch_size,
    steps,
    step_size,
    noise_scale,
    device,
    add_noise,
    clamp_min,
    clamp_max,
    max_grad_norm,
):
    model.eval()

    if x_start is None:
        x = torch.rand(
            (batch_size, 1, 28, 28), device=device
        ) * (clamp_max - clamp_min) + clamp_min
    else:
        x = x_start.clone().detach().to(device)

    x.requires_grad_(True)

    for _ in range(steps):
        with torch.enable_grad():
            energy = model(x)
            grad = torch.autograd.grad(energy.sum(), x)[0]

        with torch.no_grad():
            grad = torch.clamp(grad, -max_grad_norm, max_grad_norm)
            x.data -= 0.5 * step_size * grad

            if add_noise and noise_scale > 0:
                x.data += noise_scale * torch.randn_like(x)

            x.data.clamp_(clamp_min, clamp_max)

    return x.detach()


def generate_samples(model, cfg, device, steps=None):
    l_cfg = cfg["langevin"]
    t_cfg = cfg["training"]

    return langevin_sampling(
        model=model,
        x_start=None,
        batch_size=cfg["sampling"]["n_samples"],
        steps=l_cfg["steps"] if steps is None else steps,
        step_size=l_cfg["step_size"],
        noise_scale=l_cfg["noise_scale"],
        device=device,
        add_noise=True,
        clamp_min=l_cfg["clamp_min"],
        clamp_max=l_cfg["clamp_max"],
        max_grad_norm=t_cfg["max_grad_norm"],
    )
