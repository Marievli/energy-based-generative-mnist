import os
import torch
from src.sampling import langevin_sampling
from src.sampling import replay_buffer

class Trainer:
    def __init__(
        self,
        model,
        optimizer,
        train_loader,
        replay_buffer,
        cfg,
        device,
        scheduler=None,
        checkpoint_dir="checkpoints",
    ):
        self.model = model
        self.optimizer = optimizer
        self.train_loader = train_loader
        self.replay_buffer = replay_buffer
        self.cfg = cfg
        self.device = device
        self.scheduler = scheduler

        self.checkpoint_dir = checkpoint_dir
        self.best_delta = float("inf")
        self.history = {
            "loss": [],
            "data": [],
            "reg": [],
            "E_real": [],
            "E_fake": [],
        }

        os.makedirs(self.checkpoint_dir, exist_ok=True)
        os.makedirs(os.path.join(self.checkpoint_dir, "all_epochs"), exist_ok=True)
        
        
    def train_one_epoch(model, train_loader, optimizer, langevin_sampling,
                    device, epoch, cfg, checkpoint_dir, history, best_delta, 
                    steps=None, step_size=None, noise=None):
        
        model.train()
        
        # Initialize parameters
        lambda_reg = float(cfg["training"]["lambda_reg"]) 
        log_interval = int(cfg["training"]["log_interval"])
        
        all_epochs_dir = os.path.join(checkpoint_dir, "all_epochs")
        os.makedirs(all_epochs_dir, exist_ok=True)
        checkpoint_path = os.path.join(checkpoint_dir, "ebm_best_model.pth")

        l_steps = steps if steps is not None else int(cfg["langevin"]["steps"])
        l_step_size = step_size if step_size is not None else float(cfg["langevin"]["step_size"])
        l_noise = noise if noise is not None else float(cfg["langevin"]["noise_scale"])
        c_min, c_max = float(cfg["langevin"]["clamp_min"]), float(cfg["langevin"]["clamp_max"])

        sum_loss = sum_data = sum_reg = sum_E_real = sum_E_fake = 0.0
        total_samples = 0
        consecutive_stable_batches = 0 

        print(f"{'Batch':>6} | {'Loss':>12} | {'Data':>12} | {'Reg':>12} | {'E_real':>12} | {'E_fake':>12}")
        print("-" * 95)

        for i, (x_real, _) in enumerate(train_loader):
            x_real = x_real.to(device)
            bs = x_real.size(0)
            
            x_start = torch.rand_like(x_real) 
            
            model.eval()
            with torch.enable_grad():
                x_fake = langevin_sampling(model, x_start, bs, l_steps, l_step_size, l_noise, device, True, c_min, c_max)
            model.train()

            optimizer.zero_grad()
            E_real = model(x_real).view(-1)
            E_fake = model(x_fake).view(-1)

            data_term = E_real.mean() - E_fake.mean()
            current_batch_delta = data_term.item()
            current_batch_E_real = E_real.mean().item()

            # MID-BATCH BIDIRECTIONAL CONTROL
            if (current_batch_delta > 0.5) or (current_batch_E_real < -0.2) or torch.isnan(data_term):
                consecutive_stable_batches = 0
                if os.path.exists(checkpoint_path):
                    # print(f"\n⚠️  [BRAKE] Batch {i}: Instability. Rolling back & Slowing down...")
                    model.load_state_dict(torch.load(checkpoint_path))
                
                for param_group in optimizer.param_groups:
                    param_group['lr'] *= 0.7 
                
                lambda_reg *= 1.2
                l_step_size *= 0.8 
                cfg["training"]["lambda_reg"] = lambda_reg
                continue 

            else:
                consecutive_stable_batches += 1
                if consecutive_stable_batches >= 50: 
                    for param_group in optimizer.param_groups:
                        param_group['lr'] = min(float(cfg["training"]["lr"]) * 1.5, param_group['lr'] * 1.05)
                    lambda_reg = max(0.0001, lambda_reg * 0.95)
                    cfg["training"]["lambda_reg"] = lambda_reg
                    consecutive_stable_batches = 0

            # Loss calculation
            reg_term = lambda_reg * (E_real.pow(2).mean() + E_fake.pow(2).mean())
            loss = data_term + reg_term
            
            loss.backward()
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=0.1) 
            optimizer.step()

            
            with torch.no_grad():
                for j in range(bs):
                    replay_buffer.append(x_fake[j:j+1].detach().cpu())
                    
                sum_loss += loss.item() * bs
                sum_data += current_batch_delta * bs
                sum_reg += reg_term.item() * bs
                sum_E_real += current_batch_E_real * bs
                sum_E_fake += E_fake.mean().item() * bs
                total_samples += bs

            if i % log_interval == 0:
                print(f"{i:6d} | {loss.item():12.6f} | {current_batch_delta:12.6f} | {reg_term.item():12.6f} | {current_batch_E_real:12.6f} | {E_fake.mean().item():12.6f}")

        avg_loss = sum_loss / total_samples
        avg_data = sum_data / total_samples
        avg_reg = sum_reg / total_samples
        avg_E_real = sum_E_real / total_samples
        avg_E_fake = sum_E_fake / total_samples

        print("-" * 95)
        print(f"{'Summary':>12} | {avg_loss:12.6f} | {avg_data:12.6f} | {avg_reg:12.6f} | {avg_E_real:12.6f} | {avg_E_fake:12.6f}")

        # Checkpoint saving
        current_epoch_path = os.path.join(all_epochs_dir, f"ebm_epoch_{epoch:03d}.pth")
        torch.save(model.state_dict(), current_epoch_path)
        print(f"--> [CHECKPOINT] Saved Epoch {epoch} to {current_epoch_path}")

        if avg_data < best_delta:
            best_delta = avg_data
            torch.save(model.state_dict(), checkpoint_path)
            print(f"--> [SAVE] New Best ΔE: {best_delta:.6f} (Best Model Updated)")
        
        print("-" * 95)

        for k, v in zip(["loss", "data", "reg", "E_real", "E_fake"], [avg_loss, avg_data, avg_reg, avg_E_real, avg_E_fake]):
            history.setdefault(k, []).append(v)

        return history, best_delta

    def train(self):
        epochs = int(self.cfg["training"]["epochs"])

        for epoch in range(epochs):
            print(f"\n=== Epoch {epoch + 1}/{epochs} ===")
            self.train_one_epoch(epoch)

            if self.scheduler is not None:
                self.scheduler.step(self.history["data"][-1])
